# Fernwood Logistics — Responsive Company Website

A responsive, 4-page company website built for **Task 1: Responsive Company Website**
(WeIntern Pvt Ltd — Full Stack Development, Week 2).

**Live demo:** _add your deployed link here (GitHub Pages / Netlify / Vercel)_

## Project purpose

A fictional freight & supply-chain company site demonstrating multi-page structure,
responsive navigation, and a validated contact form. Visual concept: a
**shipping-manifest / route-map** motif — navy + signal-orange, mono "tracking number"
style data labels — chosen to fit the logistics subject rather than a generic corporate look.

## Tech stack

- HTML5, CSS3 (custom properties, Flexbox, Grid, media queries), vanilla JavaScript
- Google Fonts: Archivo, Inter, JetBrains Mono
- No build step, no frameworks (Bootstrap/Tailwind intentionally not used, per handbook's
  "optional" note)

## Pages

- **Home** (`index.html`) — hero with route-map graphic, stats strip, services preview,
  testimonial, CTA
- **About** (`about.html`) — story, mission, milestones timeline, values, team
- **Services** (`services.html`) — 6 service cards (Freight Forwarding, Warehousing, Customs
  Clearance, Fleet Management, Last-Mile Delivery, Supply Chain Consulting)
- **Contact** (`contact.html`) — contact info, map placeholder, validated form (name, company,
  email, phone, service, message)

## Key features

- Responsive nav bar with hamburger menu below 860px
- Consistent footer across all four pages (nav links, services, contact, social)
- Flexbox + CSS Grid layouts throughout
- Contact form validation via HTML5 `required`/`type` attributes plus a JS check
- Touch-friendly buttons and inputs (48px minimum height)
- Visible focus states on all interactive elements

## File structure

```
fernwood-logistics/
├── index.html
├── about.html
├── services.html
├── contact.html
├── css/
│   └── style.css
├── js/
│   └── script.js
├── screenshots/
└── README.md
```

## Setup / run instructions

No dependencies. Open `index.html` directly, or serve locally:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploying

Push to GitHub and enable **GitHub Pages**, or drag-and-drop into **Netlify** / **Vercel** —
static HTML/CSS/JS, no build command needed.

## Before submitting

- [ ] Add screenshots to `screenshots/`: all 4 pages on mobile, tablet, and desktop
- [ ] Write a short note on design decisions (the route-map motif, color choices)
- [ ] Update the live demo link above once deployed
